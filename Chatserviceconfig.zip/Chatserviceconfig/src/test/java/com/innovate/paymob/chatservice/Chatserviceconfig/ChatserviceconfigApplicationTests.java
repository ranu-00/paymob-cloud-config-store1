package com.innovate.paymob.chatservice.Chatserviceconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatserviceconfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
